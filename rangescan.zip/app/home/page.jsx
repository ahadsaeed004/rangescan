"use client";

export default function Home() {
  return (
    <main className="text-gray-800">

      {/* NAVBAR SPACING */}

      {/* HERO */}
      
      <section className="bg-orange-500 py-14 md:py-10 lg:py-24 text-center px-4">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
          Free Target Scoring in Your Pocket
        </h1>

        <p className="max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-white mb-8">
          Snap a photo of your target. Get instant scores and group analysis.
          Track your progress over time.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="https://play.google.com/store/apps/details?id=com.tlc.rangescan"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 bg-white text-black rounded-lg hover:bg-orange-100 transition text-center"
          >
            Download Now, Free Forever
          </a>

          <button className="px-6 py-3 border border-white text-white rounded-lg hover:bg-orange-600 transition">
            <a href="/target" className="text-white">Download PulseAim Target</a>
          </button>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-12 md:py-10 lg:py-24 bg-white px-4 border-t-4 border-orange-500">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          Turn Every Target Into Training Data
        </h2>

        <div className="max-w-6xl mx-auto grid sm:grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <ul className="space-y-4 text-base sm:text-lg text-black">
            <li>✓ Enter caliber & distance for MOA & group size</li>
            <li>✓ Snap a picture → instant score & analysis</li>
            <li>✓ Shooting sessions saved automatically</li>
            <li>✓ Track progress over weeks & months</li>
            <li>✓ Connect with certified instructors</li>
          </ul>

          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            {[1, 2].map((img) => (
              <div key={img} className="text-center">
                <div className="w-40 h-80 sm:w-48 sm:h-96 rounded-lg overflow-hidden mx-auto">
                  <img
                    src={`https://www.rangescan.com/rangeScan${img}.png`}
                    alt={`RangeScan ${img}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="mt-3 text-sm text-white">
                  RangeScan {img === 1 ? "Loadout" : "Target"}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
     <section className="pt-4 pb-12 md:pt-8 md:pb-20 lg:pt-10 lg:pb-24 bg-white px-4">

        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          How It Works
        </h2>

        <div className="max-w-5xl mx-auto grid sm:grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {["Download & Shoot", "Snap Photo", "Auto Save", "Share Progress"].map((title, i) => (
            <div key={i}>
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-white text-black flex items-center justify-center text-xl font-bold  shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
                {i + 1}
              </div>
              <h3 className="font-semibold">{title}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* WHY RANGESCAN */}
     <section className="pt-4 pb-12 md:pt-8 md:pb-20 lg:pt-10 lg:pb-24 bg-white px-4">

        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          Why RangeScan
        </h2>

        <div className="max-w-6xl mx-auto grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-center">
          {[
            ["💰", "Completely Free", "No hidden fees"],
            ["🎯", "Works Anywhere", "Any range, paper targets"],
            ["📱", "No Hardware", "Just your phone camera"],
            ["⚡", "Instant Results", "Immediate scoring"],
            ["👨‍🏫", "Coach Integration", "Instructor feedback"],
          ].map(([icon, title, desc], i) => (
            <div key={i} className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
              <div className="text-4xl mb-4">{icon}</div>
              <h3 className="font-bold text-lg">{title}</h3>
              <p className="text-black">{desc}</p>
            </div>
            
          ))}
        </div>
      </section>
          
      {/* FAQ */}
      <section className="py-12 md:py-10 lg:py-10 bg-white px-4">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          Frequently Asked Questions
        </h2>

        <div className="max-w-3xl mx-auto space-y-6">
          {[
            ["Is RangeScan really free?", "Yes, completely free."],
            ["What targets does it work with?", "Standard & custom paper targets."],
            ["Do I need special equipment?", "No, just your phone camera."],
            ["How accurate is the scoring?", "90%+ accuracy with ScanTune tools."],
          ].map(([q, a], i) => (
            <div key={i} className="bg-white p-6 rounded-lg border-orange-500 border-l-4 shadow hover:shadow-lg transition transform hover:-translate-y-1">
              <h4 className="font-semibold mb-2 text-black">{q}</h4>
              <p className="text-gray-700">{a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* DOWNLOAD */}
      <section className="py-2 md:py-10 lg:py-2 bg-white text-black text-center px-4">
        <h2 className="text-3xl sm:text-4xl font-bold mb-12">Download Now</h2>
        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
          <button className="px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition">
            <a
              href="https://apps.apple.com/pk/app/rangescan/id6754168802"
              target="_blank"
              className="block w-full h-full"
            >
              Download for iOS
          </a>
          </button>
          <button className="px-6 py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition">
          <a
            href="https://play.google.com/store/apps/details?id=com.tlc.rangescan"
            target="_blank"
             className="block w-full h-full"
            
          >
            Download for Android
          </a>
          </button>
        </div>
      </section>

    </main>
  );
}
