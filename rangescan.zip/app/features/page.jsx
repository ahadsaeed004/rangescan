"use client";

export default function FeaturesPage() {
  return (
    <main className="text-gray-800">

      {/* PAGE HEADER */}
      <section className="py-10 md:py-10 bg-orange-500 text-center text-white">
        <div className="mx-auto max-w-4xl px-4">
          <h1 className="mb-4 text-3xl md:text-4xl font-bold">
            RangeScan Features
          </h1>
          <p className="text-lg md:text-xl opacity-90">
            Everything you need for professional target scoring and training progress.
          </p>
        </div>
      </section>

      {/* CORE FUNCTIONALITY */}
      <section className="py-16 md:py-10 bg-white">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-black mb-12">
          Core Functionality
        </h2>

        <div className="max-w-6xl mx-auto grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-4 ">
          {[
            ["🎯", "Instant Target Analysis", "90%+ accurate scoring using advanced computer vision."],
            ["📏", "Group Size Measurement", "Automatic group size & consistency tracking."],
            ["📋", "Multiple Target Support", "NRA, B-series, PulseAim, and custom targets."],
            ["✏️", "ScanTune™", "Manual correction tools for perfect accuracy."],
            ["📐", "MOA & Ballistics", "True MOA and distance-calibrated measurements."],
            ["⚙️", "Smart Configuration", "Save and reuse shooting configurations."],
          ].map(([icon, title, desc], i) => (
            <div
              key={i}
              className="bg-white p-6 rounded-xl shadow hover:-translate-y-1 transition transform border-t-4 border-orange-500"
            >
              <div className="text-3xl mb-3">{icon}</div>
              <h3 className="font-bold text-xl mb-2">{title}</h3>
              <p className="text-black">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SHARING & COLLABORATION */}
      <section className="py-16 md:py-20 bg-white">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-black mb-12">
          Sharing & Collaboration
        </h2>

        <div className="max-w-6xl mx-auto grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-4">
          {[
            ["👨‍🏫", "Coach Integration", "Connect with certified instructors."],
            ["💬", "Remote Coaching", "Receive feedback between lessons."],
            ["📤", "Session Sharing", "Share with teammates and partners."],
            ["👥", "Group Training", "Compare team performance."],
            ["📄", "Export Reports", "Professional PDF documentation."],
            ["🔒", "Privacy Controls", "Full control over shared data."],
          ].map(([icon, title, desc], i) => (
            <div key={i} className="bg-white p-6 rounded-xl shadow hover:-translate-y-1 transition transform border-t-4 border-orange-500">
              <div className="text-3xl mb-3">{icon}</div>
              <h3 className="font-bold text-xl mb-2">{title}</h3>
              <p className="text-black">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TECHNICAL SPECS */}
      <section className="py-16 md:py-10 bg-white">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-black mb-12 ">
          Technical Specifications
        </h2>

        <div className="max-w-5xl mx-auto grid sm:grid-cols-1 md:grid-cols-2 gap-6 px-4 shadow-lime-200">
          {[
            "Offline capable – no internet required",
            "Cloud sync across devices",
            "Under 5 seconds processing time",
            "Battery efficient",
            "90%+ scoring accuracy",
            "iOS & Android compatible",
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4  bg-white p-4 border-t-4 border-orange-500 rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1">
              <span className="w-6 h-6 flex items-center justify-center bg-orange-500 text-white rounded-full">
                ✓
              </span>
              <p>{item}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-2 bg-white text-black text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Ready to Transform Your Training?
        </h2>
        <p className="mb-8 text-lg md:text-xl">
          Download RangeScan and start tracking your progress today.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
          <a
            href="https://apps.apple.com/pk/app/rangescan/id6754168802"
            target="_blank"
            className="px-6 py-3 bg-orange-500 text-white hover:bg-orange-600 rounded-lg font-semibold w-full sm:w-auto inline-block"
          >
            Download for iOS
          </a>
          <a
            href="https://play.google.com/store/apps/details?id=com.tlc.rangescan"
            target="_blank"
            className="px-6 py-3 bg-orange-500 text-white hover:bg-orange-600 rounded-lg font-semibold w-full sm:w-auto inline-block"
          >
            Download for Android
          </a>
        </div>
      </section>

    </main>
  );
}
