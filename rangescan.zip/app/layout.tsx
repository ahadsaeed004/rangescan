import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Header from "./components/header";
import Footer from "./components/footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://rangescans.com"),

  title: {
    default: "RangeScan – Smart Target Scoring System",
    template: "%s | RangeScan",
  },

  description:
    "RangeScan is a smart firearm target scoring platform that lets shooters and instructors instantly scan, review, and finalize scores using just a phone camera.",

  keywords: [
    "RangeScan",
    "firearm target scoring",
    "gun range technology",
    "shooting score app",
    "paper target scanning",
    "firearm training tools",
    "range instructor software",
    "shooting analytics",
    "ScanTune",
    "smart range scoring",
  ],

  authors: [{ name: "RangeScan Team", url: "https://rangescans.com" }],
  creator: "RangeScan",
  publisher: "RangeScan Technologies",
  applicationName: "RangeScan",
  generator: "Next.js",

  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://rangescans.com",
    title: "RangeScan – Smart Target Scoring",
    description:
      "Instantly scan and score firearm targets using your phone. Built for shooters, ranges, and instructors.",
    siteName: "RangeScan",
    images: [
      {
        url: "https://rangescans.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "RangeScan Smart Target Scoring",
        type: "image/jpeg",
      },
      {
        url: "https://rangescans.com/logo.png",
        width: 400,
        height: 400,
        alt: "RangeScan Logo",
        type: "image/png",
      },
    ],
  },

  twitter: {
    card: "summary_large_image",
    title: "RangeScan – Smart Target Scoring",
    description:
      "Scan firearm targets instantly using your phone. Accurate, fast, and built for instructors.",
    creator: "@rangescan",
    site: "@rangescan",
    images: ["https://rangescans.com/og-image.jpg"],
  },

  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [
      {
        url: "/apple-touch-icon.png",
        sizes: "180x180",
        type: "image/png",
      },
    ],
    other: [
      {
        rel: "android-chrome-192x192",
        url: "/android-chrome-192x192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        rel: "android-chrome-512x512",
        url: "/android-chrome-512x512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
    shortcut: "/favicon.ico",
  },

  robots: {
    index: true,
    follow: true,
    nocache: true,
    googleBot: {
      index: true,
      follow: true,
      noimageindex: false,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },

  other: {
    "theme-color": "#f97316",
    "msapplication-TileColor": "#f97316",
  },

  category: "technology",
  classification: "Firearm Training Technology",
  referrer: "origin-when-cross-origin",

  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },

  alternates: {
    canonical: "https://rangescans.com",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
