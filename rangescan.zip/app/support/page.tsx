"use client";
import Link from "next/link";

export default function SupportPage() {
  return (
    <main className="bg-white text-gray-800">

      {/* PAGE HEADER */}

      <section className="bg-orange-500 py-10 md:py-20 lg:py-30 text-center text-white px-4">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
          Frequently Asked Questions
        </h1>
        <p className="text-base sm:text-lg md:text-lg opacity-90 max-w-2xl mx-auto">
          Get help with RangeScan, coaches, or technical issues
        </p>
      </section>

      {/* FAQ */}
      
      <section className="max-w-5xl mx-auto px-4 -mt-16" >
        <div className="bg-white rounded-2xl md:rounded-4xl shadow-xl p-6 sm:p-8 md:p-10 space-y-6 md:space-y-8">

          {[
            {
              q: "How accurate is RangeScan's scoring system?",
              a: "RangeScan achieves 90%+ accuracy in most shooting conditions. Manual correction tools allow perfect adjustments."
            },
            {
              q: "What types of targets work with RangeScan?",
              a: "Most paper targets including NRA, B-series, and custom printed targets are supported."
            },
            {
              q: "Can I use RangeScan without a coach?",
              a: "Yes. Coach connections are optional and fully controlled by you."
            },
            {
              q: "How do I become a certified coach?",
              a: "Sign up on the ShoQ® Journal platform as a firearm instructor."
            },
            {
              q: "Can coaches see all my sessions?",
              a: "No. Coaches only see sessions you choose to share."
            },
            {
              q: "Does RangeScan work offline?",
              a: "Yes. Scans sync automatically once you reconnect."
            }
          ].map((item, i) => (
            <div key={i} className="border-b pb-4 md:pb-6 last:border-none border-gray-200">
              <h3 className="text-base sm:text-lg md:text-lg font-semibold text-gray-900 mb-1 md:mb-2">
                {item.q}
              </h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed">
                {item.a}
              </p>
            </div>
          ))}

          <div>
            <h3 className="text-base sm:text-lg md:text-lg font-semibold mb-1 md:mb-2">
              How do I use ScanTune™ to correct errors?
            </h3>
            <p className="text-sm sm:text-base text-gray-600">
              Use ScanTune™ to add or remove bullet holes manually.
              <Link href="/scantune" className="text-orange-600 font-semibold ml-1">
                View the complete guide →
              </Link>
            </p>
          </div>

        </div>
      </section>

      {/* CONTACT FORM */}
      <section className="py-10 sm:py-16 md:py-20 lg:py-15 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl sm:text-3xl md:text-3xl font-bold text-center mb-8 md:mb-10">
            Send Us a Message
          </h2>

          <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 md:p-8">
            <form className="grid sm:grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 md:gap-6">

              <input className="border rounded-lg p-3 w-full" placeholder="Full Name *" />
              <input className="border rounded-lg p-3 w-full" placeholder="Email Address *" />

              <select className="border rounded-lg p-3 w-full">
                <option>I am a *</option>
                <option>Shooter / Student</option>
                <option>Coach</option>
                <option>Business</option>
              </select>

              <select className="border rounded-lg p-3 w-full">
                <option>Support Category *</option>
                <option>Technical Issue</option>
                <option>Account Help</option>
                <option>Billing</option>
              </select>

              <input
                className="border rounded-lg p-3 md:col-span-2 w-full"
                placeholder="Subject *"
              />

              <textarea
                className="border rounded-lg p-3 md:col-span-2 w-full h-32"
                placeholder="Your message *"
              />

              <div className="md:col-span-2 text-center">
                <button className="bg-orange-500 text-white px-8 sm:px-10 py-3 rounded-lg font-semibold hover:bg-orange-700 transition w-full sm:w-auto">
                  Send Message
                </button>
              </div>

            </form>

            <p className="text-center text-sm text-gray-500 mt-4">
              We respond within 24 hours on business days
            </p>
          </div>
        </div>
      </section>

    </main>
  );
}
