"use client";

import Link from "next/link";

export default function CoachesPage() {
  return (
    <main className="bg-white text-gray-800">

      {/* SPACING FOR NAVBAR */}
      

      {/* HERO */}
      <section className="bg-orange-500 py-16 md:py-20 text-center text-white px-4">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">
          Firearm Instructor Dashboard
        </h1>
        <p className="text-lg md:text-xl mb-6 opacity-90">
          Free tools to manage students and grow your firearms training business
        </p>

        <a
          href="https://www.coachzr.com" 
          target="_blank"
          className="inline-block bg-white text-orange-600 px-6 sm:px-8 py-3 rounded-lg font-semibold hover:bg-orange-100 transition"
        >
          Join Zero Range Coach Network
        </a>
      </section>

      {/* STUDENT MANAGEMENT */}
     
      <section className="bg-white py-16 md:py-10 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 shadow-orange-50">
            Student Management Tools
          </h2>

          <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              ["👥", "Student Roster", "Track unlimited students and training logs."],
              ["🎯", "Lesson Generator", "Create tactical lessons instantly."],
              ["📓", "Range Logs", "Review student sessions anytime."],
              ["💬", "Session Feedback", "Comment and guide students remotely."],
              ["📢", "Messaging", "Send announcements and tips."],
              ["🆓", "Free for Coaches", "All features included at no cost."],
            ].map(([icon, title, desc], i) => (
              <div key={i} className="bg-white p-8  text-center rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-orange-500 text-white flex items-center justify-center text-2xl">
                  {icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{title}</h3>
                <p className="text-gray-600">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BUSINESS TOOLS */}
      
      <section className="bg-white py-16 md:py-10 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Business Tools
          </h2>

          <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              ["💰", "Revenue Tracking"],
              ["🔗", "Referral System"],
              ["🌐", "Marketing Support"],
              ["📈", "Student Acquisition"],
              ["🛒", "Sell Gear & Classes"],
              ["📰", "ZRIntel Exposure"],
            ].map(([icon, title], i) => (
              <div key={i} className="bg-white p-8  text-center rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-orange-500 text-white flex items-center justify-center text-2xl">
                  {icon}
                </div>
                <h3 className="font-semibold">{title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GETTING STARTED */}
     
      <section className="bg-white py-16 md:py-10 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Getting Started
          </h2>

          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            {[
              "Free Registration",
              "Invite Students",
              "Dashboard Training",
              "Start Earning",
            ].map((step, i) => (
              <div key={i} className="text-center">
                <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-white text-orange-500 flex items-center justify-center text-xl font-bold  shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
                  {i + 1}
                </div>
                <h3 className="font-semibold">{step}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      
      <section className="bg-white text-black py-16 md:py-10 text-center px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Ready to Transform Your Coaching Business?
        </h2>
        <p className="mb-6 opacity-90 text-lg md:text-xl">
          Free forever • No setup fees • Start earning immediately
        </p>

        <a
          href="https://www.coachzr.com" target="_blank"
          className="inline-block bg-orange-500 text-white px-6 sm:px-8 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
        >
          Start Free Coach Account
        </a>
      </section>

    </main>
  );
}
