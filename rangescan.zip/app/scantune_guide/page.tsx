"use client";

export default function ScanTuneGuide() {
  return (
    <main className="text-gray-800">

      {/* HERO */}
      <section className="bg-orange-500 py-14 md:py-16 lg:py-24 text-center px-4">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
          ScanTune™ Guide
        </h1>

        <p className="max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-white">
          Master manual adjustments for perfect scoring accuracy
        </p>
      </section>

      {/* DETECTION OVERVIEW */}
      <section className="pt-6 pb-12 md:pt-10 md:pb-20 lg:pt-14 lg:pb-24 bg-white px-4">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white p-6 md:p-8 rounded-lg shadow border-t-4 border-orange-500">
            <h2 className="text-2xl sm:text-3xl font-bold text-black mb-4">
              How RangeScan Detection Works
            </h2>

            <p className="text-gray-700 mb-6">
              RangeScan uses an advanced circular bullet overlay system to automatically detect and score bullet holes on your target. Based on your selected bullet diameter, it places precise circular overlays that achieve over 90% accuracy in typical shooting conditions—approaches 100% when lighting, target flatness, and phone camera setup are all optimal.
            </p>

            <div className="bg-white shadow-lg p-4 rounded-lg border-l-4 border-orange-500 mb-6">
              <h4 className="font-semibold text-black mb-1">
                Circular Bullet Overlay Mode
              </h4>
              <p className="text-gray-700">
                Fixed-size circles are placed using your selected bullet
                diameter. Best results occur with clean holes and minimal paper
                damage.
              </p>
            </div>

            <div className="bg-white shadow-lg p-4 rounded-lg border-l-4 border-orange-600">
              <h4 className="font-semibold text-black mb-1">
                ⚙️ About ScanTune™
              </h4>
              <p className="text-gray-700">
                While RangeScan's automated detection is highly accurate, ScanTune™ manual adjustment tools let you correct any detection errors caused by lighting conditions, torn paper, overlapping holes, or target imperfections. Always review results before finalizing your score.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* MANUAL TOOLS */}
      <section className="pt-4 pb-12 md:pt-8 md:pb-20 lg:pt-10 lg:pb-24 bg-white px-4">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          Manual Adjustment Tools
        </h2>

        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">

          {/* ADD HOLES */}
          <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
            <h3 className="text-xl font-bold mb-4">Adding Missing Holes</h3>

            <ul className="space-y-4 text-black">
              <li>
                <strong>How to Add:</strong> Tap <b>Add</b>, button, then press and hold (1 second) on the position where the bullet hole should be detected. A circular overlay matching your bullet diameter will appear..
              </li>
              <li>
                <strong>Placement Rules:</strong> Overlays can only be placed inside valid scoring zones. You cannot add overlays outside the scoring area (for example, zone 7 on an NRA B-8 target is outside the scoring zones).
              </li>
              <li>
                <strong>Edge Touch Scoring:</strong> If a bullet hole tears the edge and touches an inner ring, position the overlay so its edge—not its center—touches the scoring line to receive the higher score value.
              </li>
            </ul>
          </div>

          {/* REMOVE HOLES */}
          <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500">
            <h3 className="text-xl font-bold mb-4">
              Removing Incorrect Detections
            </h3>

            <ul className="space-y-4 text-black">
              <li>
                <strong>How to Remove:</strong> Tap <b>Remove</b> button, then press on the circular overlay you want to delete. The overlay will be removed and scoring will recalculate automatically.
              </li>
              <li>
                <strong>When to Remove:</strong> SRemove detections when the system incorrectly identifies paper damage, shadows, or other artifacts as bullet holes. Common false positives include staple holes, torn edges, or heavy shading.
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* GUIDELINES */}
      <section className="pt-4 pb-12 md:pt-8 md:pb-20 lg:pt-10 lg:pb-24 bg-white px-4">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          Important Guidelines
        </h2>

        <div className="max-w-4xl mx-auto space-y-6">
          {[
            [
              "Overlay Size",
              "Circular overlays always match your selected bullet diameter, not the size of the torn hole on paper. In reality, a 9mm bullet often creates a tear slightly larger than 9mm due to paper stretch and tearing. For consistency, RangeScan uses the true bullet diameter rather than the visible hole size to ensure accurate and standardized scoring across all calibers.",
            ],
            [
              "Manual Positioning",
              "You can manually offset overlays to better align with torn edges or irregular holes. This is especially useful when scoring edge touches or when the automatic detection slightly misses the hole center.",
            ],
            [
              "No Bulk Delete",
              "There is no Remove All button to prevent accidental deletion of all detections. Each overlay must be removed individually to ensure you maintain control over your adjustments.",
            ],
            [
              "Scoring Zones",
              " All overlays must be placed within valid scoring zones on your target. The system will not allow placement in non-scoring areas to maintain scoring accuracy and prevent errors.",
            ],
          ].map(([title, desc], i) => (
            <div
              key={i}
              className="bg-white p-6 rounded-lg shadow border-l-4 border-orange-500"
            >
              <h4 className="font-semibold text-black mb-2">{title}</h4>
              <p className="text-gray-700">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* WORKFLOW */}
      <section className="pt-4 pb-16 md:pt-8 md:pb-24 bg-white px-4">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-black mb-10">
          Recommended Workflow
        </h2>

        <div className="max-w-6xl mx-auto grid sm:grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            {
              title: "Initial Detection",
              desc: "Take a photo and let RangeScan automatically detect bullet holes"
            },
            {
              title: "Review Results",
              desc: "Zoom in and examine each detection for accuracy"
            },
            {
              title: "Use ScanTune™",
              desc: "Zoom in and examine each detection for accuracy."
            },
            {
              title: "Finalize Score",
              desc: "Confirm all overlays align with real holes, then finalize your score"
            },
          ].map((step, i) => (
            <div
              key={i}
              className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition transform hover:-translate-y-1 border-t-4 border-orange-500"
            >
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-orange-500 text-white flex items-center justify-center text-xl font-bold">
                {i + 1}
              </div>

              <h3 className="font-semibold text-lg mb-2">
                {step.title}
              </h3>

              <p className="text-sm text-gray-600 leading-relaxed">
                {step.desc}
              </p>
            </div>
          ))}
        </div>


        <div className="max-w-3xl mx-auto mt-12 bg-white shadow-lg p-6 rounded-lg border-l-4 border-orange-600">
          <h4 className="font-semibold text-black mb-2">💡 Pro Tip</h4>
          <p className="text-gray-700">
            Always review detections before finalizing, especially in poor
            lighting or competitive scenarios.
          </p>
        </div>
      </section>

    </main>
  );
}
