"use client";

export default function Footer() {
  return (
    <>
      {/* WHITE SPACER */}
    
      {/* FOOTER */}
      <footer className="bg-orange-500 text-white p-6 text-center">
        <ul className="flex justify-center space-x-4 mb-2">
          <li><a href="/home" className="hover:text-gray-300">Home</a></li>
          <li><a href="/features" className="hover:text-gray-300">Features</a></li>
          <li><a href="/scantune_guide" className="hover:text-gray-300">ScanTune Guide</a></li>
          <li><a href="/support" className="hover:text-gray-300">FAQ</a></li>
          <li><a href="/target" className="hover:text-gray-300">PA Targets</a></li>
        </ul>
        <p className="text-sm">&copy; 2025 RangeScan. Part of the ShoQ® Firearm Training System.</p>
      </footer>
    </>
  );
}
