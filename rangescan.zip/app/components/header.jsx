"use client";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  // Close mobile menu on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (menuOpen) setMenuOpen(false);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [menuOpen]);

  const menuItems = [
    { name: "Home", href: "/home" },
    { name: "Features", href: "/features" },
    { name: "ScanTune Guide", href: "/scantune_guide" },
    { name: "FAQ", href: "/support" },
    { name: "PA Targets", href: "/target" },
  ];

  return (
    <header className="fixed top-0 left-0 w-full bg-white text-black z-20 shadow-md">
      <div className="container mx-auto flex items-center justify-between py-2"> {/* smaller vertical padding */}
        {/* Logo */}
        <Link href="/home" className="flex-shrink-0">
          <Image
            src="/logo.png"
            alt="RangeScan Logo"
            width={60}   // logo size stays the same
            height={60}
            className="object-contain"
          />
        </Link>

        {/* Desktop Menu */}
        <ul className="hidden md:flex space-x-8 text-sm"> {/* optional: reduce menu font */}
          {menuItems.map((item) => (
            <li key={item.href}>
              <Link href={item.href} className="hover:text-orange-500">{item.name}</Link>
            </li>
          ))}
        </ul>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button 
            className="focus:outline-none text-2xl"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            ☰
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {menuOpen && (
        <ul className="md:hidden bg-white space-y-4 p-4 text-center">
          {menuItems.map((item) => (
            <li key={item.href}>
              <Link 
                href={item.href} 
                className="block hover:text-orange-200"
                onClick={() => setMenuOpen(false)}
              >
                {item.name}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </header>
  );
}
